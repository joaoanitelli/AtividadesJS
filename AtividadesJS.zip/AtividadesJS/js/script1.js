// Atividade 1

function analisar() {
    variavel = prompt("Insira uma tecla");
    alert(typeof('variavel'));
}